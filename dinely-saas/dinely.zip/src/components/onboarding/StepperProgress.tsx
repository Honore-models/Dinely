import { Check } from "lucide-react";

const steps = [
  {
    number: 1,
    title: "Owner Info",
    description: "Set up your account to manage your restaurant. This information is used to access your dashboard.",
  },
  {
    number: 2,
    title: "Restaurant Info",
    description: "Tell us about your restaurant so we can set up your workspace and customize your experience.",
  },
  {
    number: 3,
    title: "Plan Selection",
    description: "Select a plan that fits your business needs. You can upgrade or change it anytime.",
  },
  {
    number: 4,
    title: "Payment / Confirmation",
    description: "Secure your plan to unlock all features and start managing your restaurant.",
  },
];

interface StepperProgressProps {
  currentStep: number;
}

export function StepperProgress({ currentStep }: StepperProgressProps) {
  return (
    <div className="h-full py-4 pl-4 pr-0">
      <aside className="flex h-full flex-col justify-center rounded-2xl bg-green-50/40 px-7 py-8 shadow-md shadow-neutral-200">
      <div className="space-y-5">
        {steps.map((step, index) => {
          const isActive = step.number === currentStep;
          const isCompleted = step.number < currentStep;

          return (
            <div key={step.number} className="relative flex gap-4">
              {index < steps.length - 1 ? (
                <div className="absolute left-[14px] top-9 h-[70px] w-px bg-green-200" />
              ) : null}
              <div
                className={`relative z-10 grid h-7 w-7 shrink-0 place-items-center rounded-full border-2 text-sm font-bold ${
                  isCompleted || isActive
                    ? "border-[#22c51f] bg-[#22c51f] text-white"
                    : "border-[#22c51f] bg-white text-[#22c51f]"
                }`}
              >
                {isCompleted ? <Check size={16} /> : step.number}
              </div>
              <div>
                <h2 className={`text-xl font-bold ${isActive ? "text-black" : "text-neutral-950"}`}>{step.title}</h2>
                <p className="mt-1.5 max-w-xs text-xs font-medium leading-snug text-neutral-600">{step.description}</p>
              </div>
            </div>
          );
        })}
      </div>
      </aside>
    </div>
  );
}
